#include "modalidade.h"

// Construtor da classe Modalidade
Modalidade::Modalidade(const std::string& nomeModalidade, const std::string& tipo)
    : nomeModalidade(nomeModalidade), tipo(tipo) {}

// Getter para o nome da modalidade
const std::string& Modalidade::getNomeModalidade() const { return nomeModalidade; }

// Getter para o tipo da modalidade
const std::string& Modalidade::getTipo() const { return tipo; }

// Setter para o nome da modalidade
void Modalidade::setNomeModalidade(const std::string& nomeModalidade) { this->nomeModalidade = nomeModalidade; }

// Setter para o tipo da modalidade
void Modalidade::setTipo(const std::string& tipo) { this->tipo = tipo; }

// Destruidor da classe Modalidade
Modalidade::~Modalidade() {
    // Não há recursos alocados dinamicamente, então o destruidor está vazio
}


