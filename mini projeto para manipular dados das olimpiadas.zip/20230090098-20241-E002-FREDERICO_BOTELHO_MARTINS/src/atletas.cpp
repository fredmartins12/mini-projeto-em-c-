#include "atletas.h"
#include <iostream>

// Construtor da classe Atleta
Atleta::Atleta(const std::string& nome, const std::string& esporte, const std::string& pais)
    : nome(nome), esporte(esporte), pais(pais) {}

// Getter para o nome do atleta
const std::string& Atleta::getNome() const { return nome; }

// Getter para o esporte do atleta
const std::string& Atleta::getEsporte() const { return esporte; }

// Getter para o país do atleta
const std::string& Atleta::getPais() const { return pais; }

// Setter para o nome do atleta
void Atleta::setNome(const std::string& nome) { this->nome = nome; }

// Setter para o esporte do atleta
void Atleta::setEsporte(const std::string& esporte) { this->esporte = esporte; }

// Setter para o país do atleta
void Atleta::setPais(const std::string& pais) { this->pais = pais; }

// Método para imprimir as informações do atleta
void Atleta::printInfo() const {
    std::cout << "Nome: " << nome << '\n';
    std::cout << "Esporte: " << esporte << '\n';
    std::cout << "País: " << pais << '\n';
}

// Destruidor da classe Atleta
Atleta::~Atleta() {
    // Não há recursos alocados dinamicamente, então o destruidor está vazio
}
