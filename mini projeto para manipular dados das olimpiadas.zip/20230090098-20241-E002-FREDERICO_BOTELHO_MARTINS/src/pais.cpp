#include "pais.h"

// Construtor da classe Pais
Pais::Pais(const std::string& nome, const std::string& continente)
    : nome(nome), continente(continente) {}

// Getter para o nome do país
const std::string& Pais::getNome() const { return nome; }

// Getter para o continente do país
const std::string& Pais::getContinente() const { return continente; }

// Setter para o nome do país
void Pais::setNome(const std::string& nome) { this->nome = nome; }

// Setter para o continente do país
void Pais::setContinente(const std::string& continente) { this->continente = continente; }

// Destruidor da classe Pais
Pais::~Pais() {
    // Não há recursos alocados dinamicamente, então o destruidor está vazio
}

