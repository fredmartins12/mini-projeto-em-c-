#include "medalhas.h"
#include "atletas.h"
#include "modalidade.h"

// Construtor da classe Medalha
Medalha::Medalha(const std::string& tipoMedalha, int anoConquista, std::shared_ptr<Atleta> atleta, std::shared_ptr<Modalidade> modalidade)
    : tipoMedalha(tipoMedalha), anoConquista(anoConquista), atleta(atleta), modalidade(modalidade) {}

// Getter para o tipo da medalha
const std::string& Medalha::getTipoMedalha() const { return tipoMedalha; }

// Getter para o ano de conquista da medalha
int Medalha::getAnoConquista() const { return anoConquista; }

// Getter para o atleta que conquistou a medalha
std::shared_ptr<Atleta> Medalha::getAtleta() const { return atleta; }

// Getter para a modalidade em que a medalha foi conquistada
std::shared_ptr<Modalidade> Medalha::getModalidade() const { return modalidade; }

// Setter para o tipo da medalha
void Medalha::setTipoMedalha(const std::string& tipoMedalha) { this->tipoMedalha = tipoMedalha; }

// Setter para o ano de conquista da medalha
void Medalha::setAnoConquista(int anoConquista) { this->anoConquista = anoConquista; }

// Setter para o atleta que conquistou a medalha
void Medalha::setAtleta(std::shared_ptr<Atleta> atleta) { this->atleta = atleta; }

// Setter para a modalidade em que a medalha foi conquistada
void Medalha::setModalidade(std::shared_ptr<Modalidade> modalidade) { this->modalidade = modalidade; }

// Destruidor da classe Medalha
Medalha::~Medalha() {
    // Não há recursos alocados dinamicamente, então o destruidor está vazio
}

