#include "registro.h"
#include "atletas.h"
#include "modalidade.h"
#include "pais.h"
#include "medalhas.h"
#include <iostream>
#include <memory>
#include <vector>

// Definição dos vetores de objetos
std::vector<std::shared_ptr<Atleta>> todosAtletas;
std::vector<std::shared_ptr<Modalidade>> todasModalidades;
std::vector<std::shared_ptr<Pais>> todosPaises;
std::vector<std::shared_ptr<Medalha>> todasMedalhas;

// Funções para registrar dados
void registrarAtleta() {
    std::string nome, esporte, pais;
    std::cout << "Digite o nome do atleta: ";
    std::getline(std::cin, nome);
    std::cout << "Digite o esporte do atleta: ";
    std::getline(std::cin, esporte);
    std::cout << "Digite o país do atleta: ";
    std::getline(std::cin, pais);

    auto atleta = std::make_shared<Atleta>(nome, esporte, pais);
    todosAtletas.push_back(atleta);
}

void registrarModalidade() {
    std::string nomeModalidade, tipo;
    std::cout << "Digite o nome da modalidade: ";
    std::getline(std::cin, nomeModalidade);
    std::cout << "Digite o tipo da modalidade (Individual/Coletivo): ";
    std::getline(std::cin, tipo);

    auto modalidade = std::make_shared<Modalidade>(nomeModalidade, tipo);
    todasModalidades.push_back(modalidade);
}

void registrarMedalha() {
    std::string tipoMedalha;
    int anoConquista;
    std::string nomeAtleta, nomeModalidade;

    std::cout << "Digite o tipo da medalha: ";
    std::getline(std::cin, tipoMedalha);
    std::cout << "Digite o ano da conquista: ";
    std::cin >> anoConquista;
    std::cin.ignore(); // Limpar o buffer de entrada
    std::cout << "Digite o nome do atleta: ";
    std::getline(std::cin, nomeAtleta);
    std::cout << "Digite o nome da modalidade: ";
    std::getline(std::cin, nomeModalidade);

    std::shared_ptr<Atleta> atleta = nullptr;
    std::shared_ptr<Modalidade> modalidade = nullptr;

    for (const auto& a : todosAtletas) {
        if (a->getNome() == nomeAtleta) {
            atleta = a;
            break;
        }
    }

    for (const auto& m : todasModalidades) {
        if (m->getNomeModalidade() == nomeModalidade) {
            modalidade = m;
            break;
        }
    }

    if (atleta && modalidade) {
        auto medalha = std::make_shared<Medalha>(tipoMedalha, anoConquista, atleta, modalidade);
        todasMedalhas.push_back(medalha);
    } else {
        std::cout << "Atleta ou modalidade não encontrado(a).\n";
    }
}

void registrarPais() {
    std::string nome, continente;
    std::cout << "Digite o nome do país: ";
    std::getline(std::cin, nome);
    std::cout << "Digite o continente do país: ";
    std::getline(std::cin, continente);

    auto pais = std::make_shared<Pais>(nome, continente);
    todosPaises.push_back(pais);
}

// Funções para exibir dados
void exibirAtletas() {
    std::cout << "Lista de Atletas:\n";
    for (const auto& atleta : todosAtletas) {
        atleta->printInfo();
        std::cout << "----------------------\n";
    }
}

void exibirModalidades() {
    std::cout << "Lista de Modalidades:\n";
    for (const auto& modalidade : todasModalidades) {
        std::cout << "Nome: " << modalidade->getNomeModalidade()
                  << ", Tipo: " << modalidade->getTipo() << '\n';
    }
}

void exibirMedalhas() {
    std::cout << "Lista de Medalhas:\n";
    for (const auto& medalha : todasMedalhas) {
        std::cout << "Tipo: " << medalha->getTipoMedalha()
                  << ", Ano: " << medalha->getAnoConquista() << '\n';
        std::cout << "Atleta: " << medalha->getAtleta()->getNome() << '\n';
        std::cout << "Modalidade: " << medalha->getModalidade()->getNomeModalidade() << '\n';
        std::cout << "----------------------\n";
    }
}

void exibirPaises() {
    std::cout << "Lista de Países:\n";
    for (const auto& pais : todosPaises) {
        std::cout << "Nome: " << pais->getNome()
                  << ", Continente: " << pais->getContinente() << '\n';
    }
}

// Função para exibir todos os vetores
void exibirTodosOsVetores() {
    exibirAtletas();
    exibirModalidades();
    exibirMedalhas();
    exibirPaises();
}

// Função para limpar todos os vetores de objetos
void limpar() {
    todosAtletas.clear();       // Limpa o vetor de atletas
    todasModalidades.clear();  // Limpa o vetor de modalidades
    todasMedalhas.clear();     // Limpa o vetor de medalhas
    todosPaises.clear();       // Limpa o vetor de países
}
