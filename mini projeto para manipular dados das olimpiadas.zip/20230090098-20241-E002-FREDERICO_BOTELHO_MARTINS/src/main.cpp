#include <iostream>
#include "registro.h"

void menu() {
    std::cout << "Escolha uma opção:\n";
    std::cout << "1. Registrar Atleta\n";
    std::cout << "2. Registrar Modalidade\n";
    std::cout << "3. Registrar Medalha\n";
    std::cout << "4. Registrar País\n";
    std::cout << "5. Exibir Atletas\n";
    std::cout << "6. Exibir Modalidades\n";
    std::cout << "7. Exibir Medalhas\n";
    std::cout << "8. Exibir Países\n";
    std::cout << "9. Exibir Todos os Vetores\n";
    std::cout << "10. Sair\n";
}

int main() {
    int opcao;
    
    do {
        menu();
        std::cout << "Digite a opção desejada: ";
        std::cin >> opcao;
        std::cin.ignore(); // Limpar o buffer de entrada
        
        switch (opcao) {
            case 1:
                registrarAtleta();
                break;
            case 2:
                registrarModalidade();
                break;
            case 3:
                registrarMedalha();
                break;
            case 4:
                registrarPais();
                break;
            case 5:
                exibirAtletas();
                break;
            case 6:
                exibirModalidades();
                break;
            case 7:
                exibirMedalhas();
                break;
            case 8:
                exibirPaises();
                break;
            case 9:
                exibirTodosOsVetores();
                break;
            case 10:
                std::cout << "Saindo...\n";
                break;
            default:
                std::cout << "Opção inválida! Tente novamente.\n";
        }
    } while (opcao != 10);
    
    // Limpar todos os dados antes de sair
    limpar();
    std::cout << "Todos os dados foram limpos.\n";
    
    return 0;
}
