Professor acho que para rodar o arquivo o senhor vai ter que alterar o local de endereço no makefile para aonde esta salvo em seu computador, pois tive que rodar ele pelo CMD do Windows.

1- digitei cd (o endereço onde estava a pasta).
2- digitei mingw32-make
3- acessei a pasta com o final build exemplo(cd C:\programas_em_c\20230090098-20241-E002-FREDERICO_BOTELHO_MARTINS\build)
4- executei pelo próprio CMD com o comando (programa.exe)


não sei se existe maneiras mais fáceis de rodar no Windows, mas foi a maneira como o meu rodou!