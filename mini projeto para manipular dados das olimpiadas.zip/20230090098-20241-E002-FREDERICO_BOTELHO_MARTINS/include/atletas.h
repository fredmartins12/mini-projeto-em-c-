#ifndef ATLETAS_H
#define ATLETAS_H

#include <string>
#include <vector>

// Declaração da classe Atleta
class Atleta {
private:
    std::string nome;   // Nome do atleta
    std::string esporte; // Esporte praticado pelo atleta
    std::string pais;   // País de origem do atleta

public:
    // Construtor da classe Atleta
    Atleta(const std::string& nome, const std::string& esporte, const std::string& pais);
    
    // Métodos getters
    const std::string& getNome() const;
    const std::string& getEsporte() const;
    const std::string& getPais() const;
    
    // Métodos setters
    void setNome(const std::string& nome);
    void setEsporte(const std::string& esporte);
    void setPais(const std::string& pais);

    // Método para imprimir informações do atleta
    void printInfo() const;

    // Destruidor da classe Atleta
    ~Atleta();
};

#endif // ATLETAS_H

