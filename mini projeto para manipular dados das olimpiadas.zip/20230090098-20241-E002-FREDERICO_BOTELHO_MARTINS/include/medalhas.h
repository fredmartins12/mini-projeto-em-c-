#ifndef MEDALHAS_H
#define MEDALHAS_H

#include <string>
#include <memory>

class Atleta;       // Declaração antecipada da classe Atleta
class Modalidade;   // Declaração antecipada da classe Modalidade

// Declaração da classe Medalha
class Medalha {
private:
    std::string tipoMedalha;   // Tipo da medalha (por exemplo, Ouro, Prata, Bronze)
    int anoConquista;          // Ano em que a medalha foi conquistada
    std::shared_ptr<Atleta> atleta;       // Ponteiro compartilhado para o atleta que conquistou a medalha
    std::shared_ptr<Modalidade> modalidade; // Ponteiro compartilhado para a modalidade em que a medalha foi conquistada

public:
    // Construtor da classe Medalha
    Medalha(const std::string& tipoMedalha, int anoConquista, std::shared_ptr<Atleta> atleta, std::shared_ptr<Modalidade> modalidade);
    
    // Métodos getters
    const std::string& getTipoMedalha() const;
    int getAnoConquista() const;
    std::shared_ptr<Atleta> getAtleta() const;
    std::shared_ptr<Modalidade> getModalidade() const;
    
    // Métodos setters
    void setTipoMedalha(const std::string& tipoMedalha);
    void setAnoConquista(int anoConquista);
    void setAtleta(std::shared_ptr<Atleta> atleta);
    void setModalidade(std::shared_ptr<Modalidade> modalidade);

    // Destruidor da classe Medalha
    ~Medalha();
};

#endif // MEDALHAS_H

