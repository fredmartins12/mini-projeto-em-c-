#ifndef REGISTRO_H
#define REGISTRO_H

#include <vector>
#include <memory>
#include "atletas.h"
#include "modalidade.h"
#include "medalhas.h"
#include "pais.h"

// Declaração dos vetores de objetos
extern std::vector<std::shared_ptr<Atleta>> todosAtletas;
extern std::vector<std::shared_ptr<Modalidade>> todasModalidades;
extern std::vector<std::shared_ptr<Medalha>> todasMedalhas;
extern std::vector<std::shared_ptr<Pais>> todosPaises;

// Funções para registrar e exibir objetos
void registrarAtleta();
void registrarModalidade();
void registrarMedalha();
void registrarPais();
void exibirAtletas();
void exibirModalidades();
void exibirMedalhas();
void exibirPaises();
void exibirTodosOsVetores();

// Funções para limpar os vetores de objetos
void limpar();

#endif // REGISTRO_H
