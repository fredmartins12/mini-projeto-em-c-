#ifndef PAIS_H
#define PAIS_H

#include <string>

// Declaração da classe Pais
class Pais {
private:
    std::string nome;        // Nome do país (por exemplo, Brasil, Japão)
    std::string continente;  // Continente em que o país está localizado (por exemplo, América do Sul, Ásia)

public:
    // Construtor da classe Pais
    Pais(const std::string& nome, const std::string& continente);
    
    // Métodos getters
    const std::string& getNome() const;
    const std::string& getContinente() const;
    
    // Métodos setters
    void setNome(const std::string& nome);
    void setContinente(const std::string& continente);

    // Destruidor da classe Pais
    ~Pais();
};

#endif // PAIS_H

