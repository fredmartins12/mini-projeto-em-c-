#ifndef MODALIDADE_H
#define MODALIDADE_H

#include <string>

// Declaração da classe Modalidade
class Modalidade {
private:
    std::string nomeModalidade; // Nome da modalidade (por exemplo, Futebol, Natação)
    std::string tipo;           // Tipo da modalidade (Individual ou Coletivo)

public:
    // Construtor da classe Modalidade
    Modalidade(const std::string& nomeModalidade, const std::string& tipo);
    
    // Métodos getters
    const std::string& getNomeModalidade() const;
    const std::string& getTipo() const;
    
    // Métodos setters
    void setNomeModalidade(const std::string& nomeModalidade);
    void setTipo(const std::string& tipo);

    // Destruidor da classe Modalidade
    ~Modalidade();
};

#endif // MODALIDADE_H



